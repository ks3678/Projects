﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public GameObject objectToInstantiate;
    public GameObject spaceship;
    public GameObject bullet;
    
    private Vector2 facingDirection;
    private Vector2 unitFacingDirection;

    private float bulletSpeed;
    private float velocity;
    private float timeLeft;

    private CollisionManager collision;

    private GameObject asteroid;

    public List<GameObject> bulletList;
    public List<Vector2> facingDirectionList;
    // Start is called before the first frame update
    void Start()
    {
        //make list 

        bulletList = new List<GameObject>();
        facingDirectionList = new List<Vector2>();
        bulletSpeed = 0.1f;
        timeLeft = 1;

        collision = GameObject.Find("CollisionManager").GetComponent<CollisionManager>();
    }

    // Update is called once per frame
    void Update()
    {
        timeLeft -= Time.deltaTime;

        //if timer = 0 then add a new bullet to list
        if(Input.GetKey(KeyCode.Space) && timeLeft <= 0)
        {
            generateBullet();
            timeLeft = 1;
        }

        for(int i=0; i<bulletList.Count; i++)
        {
            velocity = bulletSpeed;

            bulletList[i].transform.position = new Vector2(bulletList[i].transform.position.x + velocity * facingDirectionList[i].x, bulletList[i].transform.position.y + velocity * facingDirectionList[i].y);

            if (bulletList[i].transform.position.x > 11 || bulletList[i].transform.position.x < -11 || bulletList[i].transform.position.y > 6 || bulletList[i].transform.position.y < -6)
            {
                Destroy(bulletList[i]);
                bulletList.RemoveAt(i);
                facingDirectionList.RemoveAt(i);
            }
        }
    }

    void generateBullet()
    {
        //makes bullet
        bulletList.Add(Instantiate(objectToInstantiate, new Vector2(spaceship.transform.position.x, spaceship.transform.position.y), Quaternion.identity));
        bulletList[bulletList.Count-1].SetActive(true);
        unitFacingDirection = GameObject.Find("ship").GetComponent<Vehicle>().direction;
        facingDirection = unitFacingDirection;
        unitFacingDirection.Normalize();

        facingDirectionList.Add(facingDirection);
    }
}
