﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Vehicle : MonoBehaviour {

    public Vector3 vehiclePos;
    public Vector3 direction;
    public Vector3 velocity;
    public Vector3 acceleration;
    private float drag = 0.03f;

    public float speed = 0.1f;
    public float maxSpeed = 0.5f;

    public int health;

    public bool gameOver;

	// Use this for initialization
	void Start () {
        vehiclePos = new Vector3(3, 0);
        direction = new Vector3(1, 0);
        velocity = new Vector3(0, 0);


        health = 3;

	}
	
	// Update is called once per frame
	void Update () {

        Movement();

        if(health <= 0)
        {
            gameOver = true;
        }

        if(gameOver)
        {
            Application.Quit();
        }
    }

    void Movement()
    {
        if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A))
        {
            direction = Quaternion.Euler(0, 0, -1) * direction;
        }
        if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D))
        {
            direction = Quaternion.Euler(0, 0, 1) * direction;
        }

        if (Input.GetKey(KeyCode.W))
        {
            speed += 0.1f;
        }

        if (Input.GetKey(KeyCode.S))
        {
            speed -= 0.1f;
        }

        acceleration = new Vector3(0, 0);
        if (Input.GetKey(KeyCode.UpArrow))
        {
            acceleration = speed * direction * Time.deltaTime;
        }
        else if (Input.GetKey(KeyCode.DownArrow))
        {
            //acceleration decreases due to drag
            acceleration = -speed * direction * Time.deltaTime;
        }

        //velocity decreases due to decceleration
        acceleration += (-drag) * velocity;

        velocity += acceleration;


        //velocity = speed * direction * Time.deltaTime;
        velocity = Vector3.ClampMagnitude(velocity, maxSpeed);
        Debug.DrawLine(vehiclePos, vehiclePos + velocity);

        vehiclePos += velocity;

        if (vehiclePos.x > 10.5)
            vehiclePos.x = -10;
        if (vehiclePos.x < -10.5)
            vehiclePos.x = 10;
        if (vehiclePos.y > 5)
            vehiclePos.y = -4.5f;
        if (vehiclePos.y < -5)
            vehiclePos.y = 4.5f;

        transform.position = vehiclePos;

        float zAngle = Mathf.Atan2(direction.y, direction.x);
        zAngle *= Mathf.Rad2Deg;
        transform.rotation = Quaternion.Euler(0, 0, zAngle);
    }
}
