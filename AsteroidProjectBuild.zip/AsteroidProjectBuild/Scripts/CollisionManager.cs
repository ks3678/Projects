﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollisionManager : MonoBehaviour
{
    public GameObject asteroidtop;
    public GameObject asteroidbottom;
    public GameObject asteroidleft;
    public GameObject asteroidright;

    public GameObject spaceship;
    public GameObject bullet;

    //small asteroids
    public GameObject asteroidtopSmall;
    public GameObject asteroidbottomSmall;
    public GameObject asteroidleftSmall;
    public GameObject asteroidrightSmall;

    public GameObject asteroidtopSmall2;
    public GameObject asteroidbottomSmall2;
    public GameObject asteroidleftSmall2;
    public GameObject asteroidrightSmall2;

    private Color color;

    CollisionDetection detection;

    private SpriteRenderer spaceshipSprite;
    private SpriteRenderer bulletSprite;

    public bool collision;

    private float timer;

    // Start is called before the first frame update
    void Start()
    {
        detection = gameObject.GetComponent<CollisionDetection>();
        spaceshipSprite = spaceship.GetComponent<SpriteRenderer>();

        timer = 0f;
    }

    // Update is called once per frame
    void Update()
    {
        if(GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count > 0)
        {
            bullet = GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList[GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count - 1];
        }
        asteroidtop = GameObject.Find("AsteroidManager").GetComponent<Asteroid>().newAsteroidtop;
        asteroidbottom = GameObject.Find("AsteroidManager").GetComponent<Asteroid>().newAsteroidbottom;
        asteroidright = GameObject.Find("AsteroidManager").GetComponent<Asteroid>().newAsteroidright;
        asteroidleft = GameObject.Find("AsteroidManager").GetComponent<Asteroid>().newAsteroidLeft;

        //small asteroids
        asteroidtopSmall = GameObject.Find("AsteroidManager").GetComponent<Asteroid>().newSmallAsteroidtop;
        asteroidbottomSmall = GameObject.Find("AsteroidManager").GetComponent<Asteroid>().newSmallAsteroidbottom;
        asteroidrightSmall = GameObject.Find("AsteroidManager").GetComponent<Asteroid>().newSmallAsteroidright;
        asteroidleftSmall = GameObject.Find("AsteroidManager").GetComponent<Asteroid>().newSmallAsteroidLeft;

        asteroidtopSmall2 = GameObject.Find("AsteroidManager").GetComponent<Asteroid>().newSmallAsteroidtop2;
        asteroidbottomSmall2 = GameObject.Find("AsteroidManager").GetComponent<Asteroid>().newSmallAsteroidbottom2;
        asteroidrightSmall2 = GameObject.Find("AsteroidManager").GetComponent<Asteroid>().newSmallAsteroidright2;
        asteroidleftSmall2 = GameObject.Find("AsteroidManager").GetComponent<Asteroid>().newSmallAsteroidLeft2;

        spaceship = GameObject.Find("ship");

        Collision();

    }

    public void Collision()
    {
        //if collides with top asteroid, destroys it
        //increases score
        //destroys bullet
        if (GameObject.Find("CollisionManager").GetComponent<CollisionDetection>().CircleCollision(bullet, asteroidtop))
        {
            Destroy(asteroidtop);
            asteroidtop.SetActive(false);
            //topExist = false
            GameObject.Find("AsteroidManager").GetComponent<Asteroid>().topExist = false;
            //remove bullet from list
            if (GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count > 0)
            {
                GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.RemoveAt(GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count - 1);
            }
            if (GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.Count > 0)
            {
                GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.RemoveAt(GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.Count - 1);
            }
            Destroy(bullet);
            GameObject.Find("GameManager").GetComponent<Game>().destroyBigAsteroid();

            //generates small asteroid
            GameObject.Find("AsteroidManager").GetComponent<Asteroid>().generateSmallAsteroidTop();
            asteroidtopSmall = GameObject.Find("AsteroidManager").GetComponent<Asteroid>().newSmallAsteroidtop;
        }
        if (asteroidtopSmall != null)
        {
            //if small asteroids are destroyed, regenerate big one
            if (GameObject.Find("CollisionManager").GetComponent<CollisionDetection>().CircleCollision(bullet, asteroidtopSmall))
            {
                spaceshipSprite.color = Color.white;
                Debug.Log("small asteroid");
                Destroy(asteroidtopSmall);
                GameObject.Find("AsteroidManager").GetComponent<Asteroid>().topSmallExist = false;
                if (GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count > 0)
                {
                    GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.RemoveAt(GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count - 1);
                }
                if (GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.Count > 0)
                {
                    GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.RemoveAt(GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.Count - 1);
                }
                Destroy(bullet);
                GameObject.Find("GameManager").GetComponent<Game>().destroySmallAsteroid();
            }
        }
        if(asteroidtopSmall2 !=null)
        {
            //if small asteroids are destroyed, regenerate big one
            if (GameObject.Find("CollisionManager").GetComponent<CollisionDetection>().CircleCollision(bullet, asteroidtopSmall2))
            {
                Debug.Log("small asteroid");
                Destroy(asteroidtopSmall2);
                GameObject.Find("AsteroidManager").GetComponent<Asteroid>().topSmallExist2 = false;
                if (GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count > 0)
                {
                    GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.RemoveAt(GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count - 1);
                }
                if (GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.Count > 0)
                {
                    GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.RemoveAt(GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.Count - 1);
                }
                Destroy(bullet);
                GameObject.Find("GameManager").GetComponent<Game>().destroySmallAsteroid();
            }
        }

        //if collides with bottom asteroid, destroys it
        //increases score
        //destroys bullet
        if (GameObject.Find("CollisionManager").GetComponent<CollisionDetection>().CircleCollision(bullet, asteroidbottom))
        {
            Destroy(asteroidbottom);
            asteroidbottom.SetActive(false);
            GameObject.Find("AsteroidManager").GetComponent<Asteroid>().bottomExist = false;
            if (GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count > 0)
            {
                GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.RemoveAt(GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count - 1);
            }
            if (GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.Count > 0)
            {
                GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.RemoveAt(GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.Count - 1);
            }
            Destroy(bullet);
            GameObject.Find("GameManager").GetComponent<Game>().destroyBigAsteroid();

            //generates small asteroid
            GameObject.Find("AsteroidManager").GetComponent<Asteroid>().generateSmallAsteroidBottom();
            asteroidbottomSmall = GameObject.Find("AsteroidManager").GetComponent<Asteroid>().newSmallAsteroidbottom;
        }
        if (asteroidbottomSmall != null)
        {
            //if small asteroids are destroyed, regenerate big one
            if (GameObject.Find("CollisionManager").GetComponent<CollisionDetection>().CircleCollision(bullet, asteroidbottomSmall))
            {
                Destroy(asteroidbottomSmall);
                GameObject.Find("AsteroidManager").GetComponent<Asteroid>().bottomSmallExist = false;
                if (GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count > 0)
                {
                    GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.RemoveAt(GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count - 1);
                }
                if (GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.Count > 0)
                {
                    GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.RemoveAt(GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.Count - 1);
                }
                Destroy(bullet);
                GameObject.Find("GameManager").GetComponent<Game>().destroySmallAsteroid();
            }
        }
        if (asteroidbottomSmall2 != null)
        {
            //if small asteroids are destroyed, regenerate big one
            if (GameObject.Find("CollisionManager").GetComponent<CollisionDetection>().CircleCollision(bullet, asteroidbottomSmall2))
            {
                Destroy(asteroidbottomSmall2);
                GameObject.Find("AsteroidManager").GetComponent<Asteroid>().bottomSmallExist2 = false;
                if (GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count > 0)
                {
                    GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.RemoveAt(GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count - 1);
                }
                if (GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.Count > 0)
                {
                    GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.RemoveAt(GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.Count - 1);
                }
                Destroy(bullet);
                GameObject.Find("GameManager").GetComponent<Game>().destroySmallAsteroid();
            }
        }

        //if collides with right asteroid, destroys it
        //increases score
        //destroys bullet
        if (GameObject.Find("CollisionManager").GetComponent<CollisionDetection>().CircleCollision(bullet, asteroidright))
        {
            Destroy(asteroidright);
            asteroidright.SetActive(false);
            GameObject.Find("AsteroidManager").GetComponent<Asteroid>().rightExist = false;
            if (GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count > 0)
            {
                GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.RemoveAt(GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count - 1);
            }
            if (GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.Count > 0)
            {
                GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.RemoveAt(GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.Count - 1);
            }
            Destroy(bullet); 
            GameObject.Find("GameManager").GetComponent<Game>().destroyBigAsteroid();

            //generates small asteroid
            GameObject.Find("AsteroidManager").GetComponent<Asteroid>().generateSmallAsteroidRight();
            asteroidrightSmall = GameObject.Find("AsteroidManager").GetComponent<Asteroid>().newSmallAsteroidright;
        }
        if (asteroidrightSmall != null)
        {
            //if small asteroids are destroyed, regenerate big one
            if (GameObject.Find("CollisionManager").GetComponent<CollisionDetection>().CircleCollision(bullet, asteroidrightSmall))
            {
                Destroy(asteroidrightSmall);
                GameObject.Find("AsteroidManager").GetComponent<Asteroid>().rightSmallExist = false;
                if (GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count > 0)
                {
                    GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.RemoveAt(GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count - 1);
                }
                if (GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.Count > 0)
                {
                    GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.RemoveAt(GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.Count - 1);
                }
                Destroy(bullet);
                GameObject.Find("GameManager").GetComponent<Game>().destroySmallAsteroid();
            }
        }
        if (asteroidrightSmall2 != null)
        {
            //if small asteroids are destroyed, regenerate big one
            if (GameObject.Find("CollisionManager").GetComponent<CollisionDetection>().CircleCollision(bullet, asteroidrightSmall2))
            {
                Destroy(asteroidrightSmall2);
                GameObject.Find("AsteroidManager").GetComponent<Asteroid>().rightSmallExist2 = false;
                if (GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count > 0)
                {
                    GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.RemoveAt(GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count - 1);
                }
                if (GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.Count > 0)
                {
                    GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.RemoveAt(GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.Count - 1);
                }
                Destroy(bullet);
                GameObject.Find("GameManager").GetComponent<Game>().destroySmallAsteroid();
            }
        }

        //if collides with left asteroid, destroys it
        //increases score
        //destroys bullet
        if (GameObject.Find("CollisionManager").GetComponent<CollisionDetection>().CircleCollision(bullet, asteroidleft))
        {
            Destroy(asteroidleft);
            asteroidleft.SetActive(false);
            GameObject.Find("AsteroidManager").GetComponent<Asteroid>().leftExist = false;
            if (GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count > 0)
            {
                GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.RemoveAt(GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count - 1);
            }
            if (GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.Count > 0)
            {
                GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.RemoveAt(GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.Count - 1);
            }
            Destroy(bullet);
            GameObject.Find("GameManager").GetComponent<Game>().destroyBigAsteroid();

            //generates small asteroid
            GameObject.Find("AsteroidManager").GetComponent<Asteroid>().generateSmallAsteroidLeft();
            asteroidleftSmall = GameObject.Find("AsteroidManager").GetComponent<Asteroid>().newSmallAsteroidLeft;
        }
        if (asteroidleftSmall != null)
        {
            //if small asteroids are destroyed, regenerate big one
            if (GameObject.Find("CollisionManager").GetComponent<CollisionDetection>().CircleCollision(bullet, asteroidleftSmall))
            {
                Destroy(asteroidleftSmall);
                GameObject.Find("AsteroidManager").GetComponent<Asteroid>().leftSmallExist = false;
                if (GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count > 0)
                {
                    GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.RemoveAt(GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count - 1);
                }
                if (GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.Count > 0)
                {
                    GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.RemoveAt(GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.Count - 1);
                }
                Destroy(bullet);
                GameObject.Find("GameManager").GetComponent<Game>().destroySmallAsteroid();
            }
        }
        if (asteroidleftSmall2 != null)
        {
            //if small asteroids are destroyed, regenerate big one
            if (GameObject.Find("CollisionManager").GetComponent<CollisionDetection>().CircleCollision(bullet, asteroidleftSmall2))
            {
                Destroy(asteroidleftSmall2);
                GameObject.Find("AsteroidManager").GetComponent<Asteroid>().leftSmallExist2 = false;
                if (GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count > 0)
                {
                    GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.RemoveAt(GameObject.Find("BulletManager").GetComponent<Bullet>().bulletList.Count - 1);
                }
                if (GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.Count > 0)
                {
                    GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.RemoveAt(GameObject.Find("BulletManager").GetComponent<Bullet>().facingDirectionList.Count - 1);
                }
                Destroy(bullet);
                GameObject.Find("GameManager").GetComponent<Game>().destroySmallAsteroid();
            }
        }




        //decreases ship health
        timer -= Time.deltaTime;

        if(timer <= 0)
        {
            if (GameObject.Find("CollisionManager").GetComponent<CollisionDetection>().CircleCollision(spaceship, asteroidtop))
            {
                GameObject.Find("ship").GetComponent<Vehicle>().health--;
                timer = 2;
            }
            if (GameObject.Find("CollisionManager").GetComponent<CollisionDetection>().CircleCollision(spaceship, asteroidbottom))
            {
                GameObject.Find("ship").GetComponent<Vehicle>().health--;
                timer = 2;
            }
            if (GameObject.Find("CollisionManager").GetComponent<CollisionDetection>().CircleCollision(spaceship, asteroidleft))
            {
                GameObject.Find("ship").GetComponent<Vehicle>().health--;
                timer = 2;
            }
            if (GameObject.Find("CollisionManager").GetComponent<CollisionDetection>().CircleCollision(spaceship, asteroidright))
            {
                GameObject.Find("ship").GetComponent<Vehicle>().health--;
                timer = 2;
            }

            if (GameObject.Find("CollisionManager").GetComponent<CollisionDetection>().CircleCollision(spaceship, asteroidtopSmall))
            {
                GameObject.Find("ship").GetComponent<Vehicle>().health--;
                timer = 2;
            }
            if (GameObject.Find("CollisionManager").GetComponent<CollisionDetection>().CircleCollision(spaceship, asteroidbottomSmall))
            {
                GameObject.Find("ship").GetComponent<Vehicle>().health--;
                timer = 2;
            }
            if (GameObject.Find("CollisionManager").GetComponent<CollisionDetection>().CircleCollision(spaceship, asteroidleftSmall))
            {
                GameObject.Find("ship").GetComponent<Vehicle>().health--;
                timer = 2;
            }
            if (GameObject.Find("CollisionManager").GetComponent<CollisionDetection>().CircleCollision(spaceship, asteroidrightSmall))
            {
                GameObject.Find("ship").GetComponent<Vehicle>().health--;
                timer = 2;
            }

            if (GameObject.Find("CollisionManager").GetComponent<CollisionDetection>().CircleCollision(spaceship, asteroidtopSmall2))
            {
                GameObject.Find("ship").GetComponent<Vehicle>().health--;
                timer = 2;
            }
            if (GameObject.Find("CollisionManager").GetComponent<CollisionDetection>().CircleCollision(spaceship, asteroidbottomSmall2))
            {
                GameObject.Find("ship").GetComponent<Vehicle>().health--;
                timer = 2;
            }
            if (GameObject.Find("CollisionManager").GetComponent<CollisionDetection>().CircleCollision(spaceship, asteroidleftSmall2))
            {
                GameObject.Find("ship").GetComponent<Vehicle>().health--;
                timer = 2;
            }
            if (GameObject.Find("CollisionManager").GetComponent<CollisionDetection>().CircleCollision(spaceship, asteroidrightSmall2))
            {
                GameObject.Find("ship").GetComponent<Vehicle>().health--;
                timer = 2;
            }
        }
    }
}
