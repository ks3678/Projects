﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Game : MonoBehaviour
{
    public int score;

    // Start is called before the first frame update
    void Start()
    {
        score = 0;
    }

    // Update is called once per frame
    void Update()
    {
        OnGUI();
    }

    public void destroyBigAsteroid()
    {
        score += 50;
    }
    public void destroySmallAsteroid()
    {
        score += 20;
    }

    private void OnGUI()
    {
       
        string scoreString = score.ToString();
        string hp = GameObject.Find("ship").GetComponent<Vehicle>().health.ToString();

        GUI.TextField(new Rect(10, 10, 200, 100), "Score: " + scoreString + "\n" + "Health: "+hp, 20);
    }
}
