﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Asteroid : MonoBehaviour
{
    public GameObject topToInstantiate, bottomToInstantiate, leftToInstantiate, rightToInstantiate;
    public GameObject topSmallToInstantiate, bottomSmallToInstantiate, leftSmallToInstantiate, rightSmallToInstantiate;
    public GameObject topSmallToInstantiate2, bottomSmallToInstantiate2, leftSmallToInstantiate2, rightSmallToInstantiate2;

    private int random1, random2, random3, random4, randomOtherSide;
    private float randomSpeed, smallrandomSpeed;
    public bool topExist, bottomExist, rightExist, leftExist;
    public bool topSmallExist, bottomSmallExist, rightSmallExist, leftSmallExist;
    public bool topSmallExist2, bottomSmallExist2, rightSmallExist2, leftSmallExist2;

    public GameObject newAsteroidtop, newAsteroidbottom, newAsteroidright, newAsteroidLeft;
    public GameObject newSmallAsteroidtop, newSmallAsteroidbottom, newSmallAsteroidright, newSmallAsteroidLeft;
    public GameObject newSmallAsteroidtop2, newSmallAsteroidbottom2, newSmallAsteroidright2, newSmallAsteroidLeft2;


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        generateAsteroid();
    }

    void generateAsteroid()
    {
        //top asteroid
        Random.seed = System.DateTime.Now.Millisecond;
        random1 = Random.Range(-13, 14);
        randomSpeed = Random.Range(0.01f, 0.1f);
        randomOtherSide = Random.Range(-13, 14);
        if (topExist == false && topSmallExist == false && topSmallExist2 == false)
        {
            newAsteroidtop = Instantiate(topToInstantiate, new Vector3(random1, 6, 0), Quaternion.identity);
            newAsteroidtop.SetActive(true);
            topExist = true;
        }
        else if(topExist == true)
        {
            Vector2 vectorFromTop = new Vector2(Mathf.Abs(randomOtherSide - newAsteroidtop.transform.position.x), Mathf.Abs(-7 - newAsteroidtop.transform.position.y));
            Vector2 unitVectorFromTop = vectorFromTop;
            unitVectorFromTop.Normalize();
            newAsteroidtop.transform.position = new Vector2(newAsteroidtop.transform.position.x - (unitVectorFromTop.x * randomSpeed), newAsteroidtop.transform.position.y - (unitVectorFromTop.y * randomSpeed));
        }
        if(topSmallExist == true)
        {
            Vector2 vectorFromTop = new Vector2(Mathf.Abs((randomOtherSide) - newSmallAsteroidtop.transform.position.x)+5, Mathf.Abs(-7 - newSmallAsteroidtop.transform.position.y));
            Vector2 unitVectorFromTop = vectorFromTop;
            unitVectorFromTop.Normalize();
            newSmallAsteroidtop.transform.position = new Vector2(newSmallAsteroidtop.transform.position.x - (unitVectorFromTop.x * randomSpeed), newSmallAsteroidtop.transform.position.y - (unitVectorFromTop.y * randomSpeed));
        }
        if(topSmallExist2 == true)
        {
            Vector2 vectorFromTop = new Vector2(Mathf.Abs((randomOtherSide) - newSmallAsteroidtop2.transform.position.x)-5, Mathf.Abs(-7 - newSmallAsteroidtop2.transform.position.y));
            Vector2 unitVectorFromTop = vectorFromTop;
            unitVectorFromTop.Normalize();
            newSmallAsteroidtop2.transform.position = new Vector2(newSmallAsteroidtop2.transform.position.x - (unitVectorFromTop.x * randomSpeed), newSmallAsteroidtop2.transform.position.y - (unitVectorFromTop.y * randomSpeed));
        }

        //bottom asteroid
        Random.seed = System.DateTime.Now.Millisecond;
        random2 = Random.Range(-13, 14);
        randomSpeed = Random.Range(0.01f, 0.1f);
        randomOtherSide = Random.Range(-13, 14);
        if (bottomExist == false && bottomSmallExist == false)
        {
            newAsteroidbottom = Instantiate(bottomToInstantiate, new Vector3(random2, -6, 0), Quaternion.identity);
            newAsteroidbottom.SetActive(true);
            bottomExist = true;
        }
        else if (bottomExist == true)
        {
            Vector2 vectorFrombottom = new Vector2(Mathf.Abs(randomOtherSide - newAsteroidbottom.transform.position.x), Mathf.Abs(6 - newAsteroidbottom.transform.position.y));
            Vector2 unitVectorFrombottom = vectorFrombottom;
            unitVectorFrombottom.Normalize();
            newAsteroidbottom.transform.position = new Vector2(newAsteroidbottom.transform.position.x + (unitVectorFrombottom.x * randomSpeed),
                                                    newAsteroidbottom.transform.position.y + (unitVectorFrombottom.y * randomSpeed));
        }
        if(bottomSmallExist == true)
        {
            Vector2 vectorFrombottom = new Vector2(Mathf.Abs((randomOtherSide) - newSmallAsteroidbottom.transform.position.x)+2, Mathf.Abs(6 - newSmallAsteroidbottom.transform.position.y));
            Vector2 unitVectorFrombottom = vectorFrombottom;
            unitVectorFrombottom.Normalize();
            newSmallAsteroidbottom.transform.position = new Vector2(newSmallAsteroidbottom.transform.position.x + (unitVectorFrombottom.x * randomSpeed),
                                                    newSmallAsteroidbottom.transform.position.y + (unitVectorFrombottom.y * randomSpeed));
        }
        if(bottomSmallExist2 == true)
        {
            Vector2 vectorFrombottom2 = new Vector2(Mathf.Abs((randomOtherSide) - newSmallAsteroidbottom2.transform.position.x)-2, Mathf.Abs(6 - newSmallAsteroidbottom2.transform.position.y));
            Vector2 unitVectorFrombottom2 = vectorFrombottom2;
            unitVectorFrombottom2.Normalize();
            newSmallAsteroidbottom2.transform.position = new Vector2(newSmallAsteroidbottom2.transform.position.x + (unitVectorFrombottom2.x * randomSpeed),
                                                    newSmallAsteroidbottom2.transform.position.y + (unitVectorFrombottom2.y * randomSpeed));
        }

        //right asteroid
        Random.seed = System.DateTime.Now.Millisecond;
        random3 = Random.Range(-6, 7);
        randomSpeed = Random.Range(0.01f, 0.1f);
        randomOtherSide = Random.Range(-6, 7);
        if (rightExist == false && rightSmallExist == false)
        {
            newAsteroidright = Instantiate(rightToInstantiate, new Vector3(13, random3, 0), Quaternion.identity);
            newAsteroidright.SetActive(true);
            rightExist = true;
        }
        else if(rightExist == true)
        {
            Vector2 vectorFromRight = new Vector2(-13 - newAsteroidright.transform.position.x, randomOtherSide - newAsteroidright.transform.position.y);
            Vector2 unitVectorFromRight = vectorFromRight;
            unitVectorFromRight.Normalize();
            newAsteroidright.transform.position = new Vector2(newAsteroidright.transform.position.x + (unitVectorFromRight.x * randomSpeed),
                                                                newAsteroidright.transform.position.y - (unitVectorFromRight.y * randomSpeed));
        }
        if(rightSmallExist == true)
        {
            Vector2 vectorFromRight = new Vector2(-12 - newSmallAsteroidright.transform.position.x, randomOtherSide - newSmallAsteroidright.transform.position.y+2);
            Vector2 unitVectorFromRight = vectorFromRight;
            unitVectorFromRight.Normalize();
            newSmallAsteroidright.transform.position = new Vector2(newSmallAsteroidright.transform.position.x + (unitVectorFromRight.x * randomSpeed),
                                                                newSmallAsteroidright.transform.position.y - (unitVectorFromRight.y * randomSpeed));
        }
        if(rightSmallExist2 == true)
        {
            Vector2 vectorFromRight2 = new Vector2(-14 - newSmallAsteroidright2.transform.position.x, randomOtherSide - newSmallAsteroidright2.transform.position.y-2);
            Vector2 unitVectorFromRight2 = vectorFromRight2;
            unitVectorFromRight2.Normalize();
            newSmallAsteroidright2.transform.position = new Vector2(newSmallAsteroidright2.transform.position.x + (unitVectorFromRight2.x * randomSpeed),
                                                                newSmallAsteroidright2.transform.position.y - (unitVectorFromRight2.y * randomSpeed));
        }

        //left asteroid
        Random.seed = System.DateTime.Now.Millisecond;
        random4 = Random.Range(-6, 7);
        randomSpeed = Random.Range(0.01f, 0.1f);
        randomOtherSide = Random.Range(-6, 7);
        if (leftExist == false && leftSmallExist == false)
        {
            newAsteroidLeft = Instantiate(leftToInstantiate, new Vector3(-13, random3, 0), Quaternion.identity);
            newAsteroidLeft.SetActive(true);
            leftExist = true;
        }
        else if (leftExist == true)
        {
            Vector2 vectorFromLeft = new Vector2(13 - newAsteroidLeft.transform.position.x, Mathf.Abs(randomOtherSide - newAsteroidLeft.transform.position.y));
            Vector2 unitVectorFromLeft = vectorFromLeft;
            unitVectorFromLeft.Normalize();
            newAsteroidLeft.transform.position = new Vector2(newAsteroidLeft.transform.position.x + (unitVectorFromLeft.x * randomSpeed),
                                                                newAsteroidLeft.transform.position.y - (unitVectorFromLeft.y * randomSpeed));
        }
        if(leftSmallExist == true)
        {
            Vector2 vectorFromLeft = new Vector2(13 - newSmallAsteroidLeft.transform.position.x, Mathf.Abs((randomOtherSide) - newSmallAsteroidLeft.transform.position.y)+2);
            Vector2 unitVectorFromLeft = vectorFromLeft;
            unitVectorFromLeft.Normalize();
            newSmallAsteroidLeft.transform.position = new Vector2(newSmallAsteroidLeft.transform.position.x + (unitVectorFromLeft.x * randomSpeed),
                                                                newSmallAsteroidLeft.transform.position.y - (unitVectorFromLeft.y * randomSpeed));
        }
        if(leftSmallExist2 == true)
        {
            Vector2 vectorFromLeft = new Vector2(13 - newSmallAsteroidLeft2.transform.position.x, Mathf.Abs((randomOtherSide) - newSmallAsteroidLeft2.transform.position.y)-2);
            Vector2 unitVectorFromLeft = vectorFromLeft;
            unitVectorFromLeft.Normalize();
            newSmallAsteroidLeft2.transform.position = new Vector2(newSmallAsteroidLeft2.transform.position.x + (unitVectorFromLeft.x * randomSpeed),
                                                                newSmallAsteroidLeft2.transform.position.y - (unitVectorFromLeft.y * randomSpeed));
        }

        //big asteroids restrictions
        if (newAsteroidLeft != null)
        {
            if (newAsteroidLeft.transform.position.x > 11 || newAsteroidLeft.transform.position.y > 7 || newAsteroidLeft.transform.position.y < -7)
            {
                Destroy(newAsteroidLeft);
                newAsteroidLeft.SetActive(false);
                leftExist = false;
            }
        }
        if(newAsteroidright != null)
        {
            if (newAsteroidright.transform.position.x < -11 || newAsteroidright.transform.position.y > 7 || newAsteroidright.transform.position.y < -7)
            {
                Destroy(newAsteroidright);
                newAsteroidright.SetActive(false);
                rightExist = false;
            }
        }
        if(newAsteroidtop != null)
        {
            if (newAsteroidtop.transform.position.y < -6 || newAsteroidtop.transform.position.x < -11)
            {
                Destroy(newAsteroidtop);
                newAsteroidtop.SetActive(false);
                topExist = false;
                Debug.Log("destroy small");
            }
        }
        if(newAsteroidbottom != null)
        {
            if (newAsteroidbottom.transform.position.y > 6 || newAsteroidbottom.transform.position.x > 11)
            {
                Destroy(newAsteroidbottom);
                newAsteroidbottom.SetActive(false);
                bottomExist = false;
            }
        }

        //small asteroids restrictions
        if(newSmallAsteroidLeft != null)
        {
            if (newSmallAsteroidLeft.transform.position.x > 11 || newSmallAsteroidLeft.transform.position.y > 5 || newSmallAsteroidLeft.transform.position.y < -5)
            {
                Destroy(newSmallAsteroidLeft);
                newSmallAsteroidLeft.SetActive(false);
                leftSmallExist = false;
            }
        }
        if(newSmallAsteroidright != null)
        {
            if (newSmallAsteroidright.transform.position.x < -11 || newSmallAsteroidright.transform.position.y > 5 || newSmallAsteroidright.transform.position.y < -5)
            {
                Destroy(newSmallAsteroidright);
                newSmallAsteroidright.SetActive(false);
                rightSmallExist = false;
            }
        }
        if(newSmallAsteroidtop != null)
        {
            if (newSmallAsteroidtop.transform.position.y < -5 || newSmallAsteroidtop.transform.position.x < -11)
            {
                Destroy(newSmallAsteroidtop);
                newSmallAsteroidtop.SetActive(false);
                topSmallExist = false;
            }
        }
        if(newSmallAsteroidbottom != null)
        {
            if (newSmallAsteroidbottom.transform.position.y > 5 || newSmallAsteroidbottom.transform.position.x > 11)
            {
                Destroy(newSmallAsteroidbottom);
                newSmallAsteroidbottom.SetActive(false);
                bottomSmallExist = false;
            }
        }

        //small asteroids 2 restrictions
        if (newSmallAsteroidLeft2 != null)
        {
            if (newSmallAsteroidLeft2.transform.position.x > 10 || newSmallAsteroidLeft2.transform.position.y > 4 || newSmallAsteroidLeft2.transform.position.y < -4)
            {
                Destroy(newSmallAsteroidLeft2);
                newSmallAsteroidLeft2.SetActive(false);
                leftSmallExist2 = false;
            }
        }
        if (newSmallAsteroidright2 != null)
        {
            if (newSmallAsteroidright2.transform.position.x < -10 || newSmallAsteroidright2.transform.position.y > 4 || newSmallAsteroidright2.transform.position.y < -4)
            {
                Destroy(newSmallAsteroidright2);
                newSmallAsteroidright2.SetActive(false);
                rightSmallExist2 = false;
            }
        }
        if (newSmallAsteroidtop2 != null)
        {
            if (newSmallAsteroidtop2.transform.position.y < -4 || newSmallAsteroidtop2.transform.position.x < -11)
            {
                Destroy(newSmallAsteroidtop2);
                newSmallAsteroidtop2.SetActive(false);
                topSmallExist2 = false;
            }
        }
        if (newSmallAsteroidbottom2 != null)
        {
            if (newSmallAsteroidbottom2.transform.position.y > 4 || newSmallAsteroidbottom2.transform.position.x > 10)
            {
                Destroy(newSmallAsteroidbottom2);
                newSmallAsteroidbottom2.SetActive(false);
                bottomSmallExist2 = false;
            }
        }
    }

    //generates small asteroids
    public void generateSmallAsteroidTop()
    {
        newSmallAsteroidtop = Instantiate(topSmallToInstantiate, new Vector2(newAsteroidtop.transform.position.x, newAsteroidtop.transform.position.y), Quaternion.identity);
        newSmallAsteroidtop.SetActive(true);
        topSmallExist = true;

        //2
        newSmallAsteroidtop2 = Instantiate(topSmallToInstantiate2, new Vector2(newAsteroidtop.transform.position.x, newAsteroidtop.transform.position.y), Quaternion.identity);
        newSmallAsteroidtop2.SetActive(true);
        topSmallExist2 = true;
    }

    public void generateSmallAsteroidBottom()
    {
        newSmallAsteroidbottom = Instantiate(bottomSmallToInstantiate, new Vector2(newAsteroidbottom.transform.position.x, newAsteroidbottom.transform.position.y), Quaternion.identity);
        newSmallAsteroidbottom.SetActive(true);
        bottomSmallExist = true;

        //2
        newSmallAsteroidbottom2 = Instantiate(bottomSmallToInstantiate2, new Vector2(newAsteroidbottom.transform.position.x, newAsteroidbottom.transform.position.y), Quaternion.identity);
        newSmallAsteroidbottom2.SetActive(true);
        bottomSmallExist2 = true;
    }

    public void generateSmallAsteroidRight()
    {
        newSmallAsteroidright = Instantiate(rightSmallToInstantiate, new Vector2(newAsteroidright.transform.position.x, newAsteroidright.transform.position.y), Quaternion.identity);
        newSmallAsteroidright.SetActive(true);
        rightSmallExist = true;

        //2
        newSmallAsteroidright2 = Instantiate(rightSmallToInstantiate2, new Vector2(newAsteroidright.transform.position.x, newAsteroidright.transform.position.y), Quaternion.identity);
        newSmallAsteroidright2.SetActive(true);
        rightSmallExist2 = true;
    }

    public void generateSmallAsteroidLeft()
    {
        newSmallAsteroidLeft = Instantiate(leftSmallToInstantiate, new Vector2(newAsteroidLeft.transform.position.x, newAsteroidLeft.transform.position.y), Quaternion.identity);
        newSmallAsteroidLeft.SetActive(true);
        leftSmallExist = true;

        //2
        newSmallAsteroidLeft2 = Instantiate(leftSmallToInstantiate2, new Vector2(newAsteroidLeft.transform.position.x, newAsteroidLeft.transform.position.y), Quaternion.identity);
        newSmallAsteroidLeft2.SetActive(true);
        leftSmallExist2 = true;
    }
}
