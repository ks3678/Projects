﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollisionDetection : MonoBehaviour
{

    private SpriteRenderer aSprite;
    private SpriteRenderer bSprite;

    private float aWidth;
    private float bWidth;

    private float aHeight;
    private float bHeight;

    private float aRaidus;
    private float bRaidus;

    private Vector3 aVector3;
    private Vector3 bVector3;

    public float distance;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
    }

    public bool AABBCollision(GameObject a, GameObject b)
    {
        //gets sprite renderer
        aSprite = a.GetComponent<SpriteRenderer>();
        bSprite = b.GetComponent<SpriteRenderer>();

        //gets width of sprite
        aWidth = aSprite.bounds.size.x;
        bWidth = bSprite.bounds.size.x;

        //height of sprite
        aHeight = aSprite.bounds.size.y;
        bHeight = bSprite.bounds.size.y;

        //sees is width/2 is greater than distance between centers
        if (Mathf.Abs(b.transform.position.x - a.transform.position.x) > (aWidth/2 + bWidth/2))
        {
            return false;
        }
        //sees if height/2 is greater than distance between centers
        else if(Mathf.Abs(b.transform.position.y - a.transform.position.y) > (aHeight / 2 + bHeight / 2))
        {
            return false;
        }

        return true;
    }

    public bool CircleCollision(GameObject a, GameObject b)
    {
        //gets spriterenderer
        if(a != null && b != null)
        {
            aSprite = a.GetComponent<SpriteRenderer>();
            bSprite = b.GetComponent<SpriteRenderer>();

            //gets radius
            aRaidus = aSprite.bounds.extents.magnitude - (float)0.2;
            bRaidus = bSprite.bounds.extents.magnitude - (float)0.2;           

            //gets the center of each circle
            aVector3 = aSprite.bounds.center;
            bVector3 = bSprite.bounds.center;

            if (b.CompareTag("test"))
            {
                Debug.Log(bRaidus);
                Debug.Log(bVector3);
            }

            //calculates distance from each circle
            distance = Mathf.Sqrt(Mathf.Pow(aVector3.x - bVector3.x, 2) + Mathf.Pow(aVector3.y - bVector3.y, 2));

            //if radius + radius is greater than distance between the center of each circle, collision detected
            if ((aRaidus + bRaidus) > distance)
            {
                return true;
            }
        }
         
        return false;
    }
}
